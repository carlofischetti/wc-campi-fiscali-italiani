jQuery(document).ready(function($) {
    'use strict';
    
    // Nascondi tutti i campi fiscali all'inizio
    $('.customer-type-field').hide();
    
    // Funzione per mostrare/nascondere i campi in base al tipo cliente
    function toggleCustomerFields() {
        var customerType = $('#billing_customer_type').val();
        
        // Nascondi tutti i campi
        $('.customer-type-field').hide();
        $('.customer-type-field input, .customer-type-field select').prop('required', false);
        
        if (customerType === 'private') {
            // Mostra campi per privati
            $('.private-field').show();
            $('#billing_codice_fiscale').prop('required', true);
        } else if (customerType === 'business') {
            // Mostra campi per aziende
            $('.business-field').show();
            $('#billing_partita_iva').prop('required', true);
        }
    }
    
    // Esegui al caricamento della pagina
    toggleCustomerFields();
    
    // Esegui quando cambia il tipo di cliente
    $(document).on('change', '#billing_customer_type', function() {
        toggleCustomerFields();
    });
    
    // Gestisci anche gli aggiornamenti del checkout di WooCommerce
    $(document.body).on('updated_checkout', function() {
        toggleCustomerFields();
    });
    
    // Formattazione automatica del Codice Fiscale
    $('#billing_codice_fiscale').on('input', function() {
        this.value = this.value.toUpperCase();
    });
    
    // Formattazione automatica del Codice SDI
    $('#billing_sdi').on('input', function() {
        this.value = this.value.toUpperCase();
        // Limita a 7 caratteri
        if (this.value.length > 7) {
            this.value = this.value.slice(0, 7);
        }
    });
    
    // Validazione Partita IVA (solo numeri)
    $('#billing_partita_iva').on('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
        // Limita a 11 cifre
        if (this.value.length > 11) {
            this.value = this.value.slice(0, 11);
        }
    });
});