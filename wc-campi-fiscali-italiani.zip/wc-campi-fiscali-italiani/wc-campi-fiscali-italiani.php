<?php
/**
 * Plugin Name: WC Campi Fiscali Italiani
 * Plugin URI: https://github.com/carlofischetti/wc-campi-fiscali-italiani
 * Description: Aggiunge campi fiscali italiani (Codice Fiscale, P.IVA, PEC, SDI) al checkout di WooCommerce
 * Version: 1.0.0
 * Author: Carlo Fischetti
 * Author URI: https://carlofischetti.it
 * Text Domain: wc-campi-fiscali-italiani
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 9.3
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit;
}

// Verifica che WooCommerce sia attivo
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

class WC_Campi_Fiscali_Italiani {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Hook per l'attivazione del plugin
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Aggiungi campi al checkout
        add_filter('woocommerce_checkout_fields', array($this, 'add_custom_checkout_fields'));
        
        // Nascondi il campo azienda di default
        add_filter('woocommerce_checkout_fields', array($this, 'hide_company_field'), 20);
        
        // Validazione campi
        add_action('woocommerce_after_checkout_validation', array($this, 'validate_custom_fields'), 10, 2);
        
        // Salva i dati nell'ordine
        add_action('woocommerce_checkout_update_order_meta', array($this, 'save_custom_fields'));
        
        // Mostra i dati nella pagina ordine admin
        add_action('woocommerce_admin_order_data_after_billing_address', array($this, 'display_admin_order_meta'), 10, 1);
        
        // Mostra i dati nella pagina "Grazie per il tuo ordine"
        add_action('woocommerce_order_details_after_customer_details', array($this, 'display_order_details'), 10, 1);
        
        // Aggiungi campi alle email
        add_filter('woocommerce_email_order_meta_fields', array($this, 'add_custom_email_fields'), 10, 3);
        
        // Enqueue scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Dichiara compatibilità HPOS
        add_action('before_woocommerce_init', array($this, 'declare_hpos_compatibility'));
    }
    
    public function activate() {
        // Niente da fare all'attivazione per ora
        flush_rewrite_rules();
    }
    
    public function declare_hpos_compatibility() {
        if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        }
    }
    
    public function add_custom_checkout_fields($fields) {
        // Aggiungi il campo select per tipo cliente
        $fields['billing']['billing_customer_type'] = array(
            'type' => 'select',
            'label' => esc_html__('Tipo di Cliente', 'wc-campi-fiscali-italiani'),
            'required' => true,
            'class' => array('form-row-wide', 'update_totals_on_change'),
            'clear' => true,
            'options' => array(
                '' => esc_html__('Seleziona...', 'wc-campi-fiscali-italiani'),
                'private' => esc_html__('Privato', 'wc-campi-fiscali-italiani'),
                'business' => esc_html__('Azienda', 'wc-campi-fiscali-italiani')
            ),
            'priority' => 25
        );
        
        // Campo Codice Fiscale (per privati)
        $fields['billing']['billing_codice_fiscale'] = array(
            'type' => 'text',
            'label' => esc_html__('Codice Fiscale', 'wc-campi-fiscali-italiani'),
            'required' => false,
            'class' => array('form-row-wide', 'customer-type-field', 'private-field'),
            'clear' => true,
            'priority' => 26,
            'custom_attributes' => array(
                'data-customer-type' => 'private'
            )
        );
        
        // Campo Partita IVA (per aziende)
        $fields['billing']['billing_partita_iva'] = array(
            'type' => 'text',
            'label' => esc_html__('Partita IVA', 'wc-campi-fiscali-italiani'),
            'required' => false,
            'class' => array('form-row-wide', 'customer-type-field', 'business-field'),
            'clear' => true,
            'priority' => 27,
            'custom_attributes' => array(
                'data-customer-type' => 'business'
            )
        );
        
        // Campo PEC (per aziende)
        $fields['billing']['billing_pec'] = array(
            'type' => 'email',
            'label' => esc_html__('PEC (Posta Elettronica Certificata)', 'wc-campi-fiscali-italiani'),
            'required' => false,
            'class' => array('form-row-first', 'customer-type-field', 'business-field'),
            'clear' => false,
            'priority' => 28,
            'custom_attributes' => array(
                'data-customer-type' => 'business'
            )
        );
        
        // Campo SDI (per aziende)
        $fields['billing']['billing_sdi'] = array(
            'type' => 'text',
            'label' => esc_html__('Codice SDI (Codice Destinatario)', 'wc-campi-fiscali-italiani'),
            'required' => false,
            'class' => array('form-row-last', 'customer-type-field', 'business-field'),
            'clear' => true,
            'priority' => 29,
            'custom_attributes' => array(
                'data-customer-type' => 'business',
                'maxlength' => '7'
            ),
            'description' => esc_html__('7 caratteri alfanumerici', 'wc-campi-fiscali-italiani')
        );
        
        return $fields;
    }
    
    public function hide_company_field($fields) {
        // Nascondi il campo azienda di default
        if (isset($fields['billing']['billing_company'])) {
            unset($fields['billing']['billing_company']);
        }
        if (isset($fields['shipping']['shipping_company'])) {
            unset($fields['shipping']['shipping_company']);
        }
        return $fields;
    }
    
    public function validate_custom_fields($data, $errors) {
        $customer_type = isset($_POST['billing_customer_type']) ? sanitize_text_field($_POST['billing_customer_type']) : '';
        
        if (empty($customer_type)) {
            $errors->add('validation', esc_html__('Seleziona il tipo di cliente.', 'wc-campi-fiscali-italiani'));
        }
        
        if ($customer_type === 'private') {
            if (empty($_POST['billing_codice_fiscale'])) {
                $errors->add('validation', esc_html__('Il Codice Fiscale è obbligatorio per i clienti privati.', 'wc-campi-fiscali-italiani'));
            } else {
                $cf = strtoupper(sanitize_text_field($_POST['billing_codice_fiscale']));
                if (!preg_match('/^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$/', $cf)) {
                    $errors->add('validation', esc_html__('Il formato del Codice Fiscale non è valido.', 'wc-campi-fiscali-italiani'));
                }
            }
        }
        
        if ($customer_type === 'business') {
            if (empty($_POST['billing_partita_iva'])) {
                $errors->add('validation', esc_html__('La Partita IVA è obbligatoria per le aziende.', 'wc-campi-fiscali-italiani'));
            } else {
                $piva = sanitize_text_field($_POST['billing_partita_iva']);
                if (!preg_match('/^[0-9]{11}$/', $piva)) {
                    $errors->add('validation', esc_html__('La Partita IVA deve contenere 11 cifre.', 'wc-campi-fiscali-italiani'));
                }
            }
            
            if (!empty($_POST['billing_sdi'])) {
                $sdi = strtoupper(sanitize_text_field($_POST['billing_sdi']));
                if (!preg_match('/^[A-Z0-9]{7}$/', $sdi)) {
                    $errors->add('validation', esc_html__('Il Codice SDI deve contenere esattamente 7 caratteri alfanumerici.', 'wc-campi-fiscali-italiani'));
                }
            }
        }
    }
    
    public function save_custom_fields($order_id) {
        if (!empty($_POST['billing_customer_type'])) {
            update_post_meta($order_id, '_billing_customer_type', sanitize_text_field($_POST['billing_customer_type']));
        }
        
        if (!empty($_POST['billing_codice_fiscale'])) {
            update_post_meta($order_id, '_billing_codice_fiscale', strtoupper(sanitize_text_field($_POST['billing_codice_fiscale'])));
        }
        
        if (!empty($_POST['billing_partita_iva'])) {
            update_post_meta($order_id, '_billing_partita_iva', sanitize_text_field($_POST['billing_partita_iva']));
        }
        
        if (!empty($_POST['billing_pec'])) {
            update_post_meta($order_id, '_billing_pec', sanitize_email($_POST['billing_pec']));
        }
        
        if (!empty($_POST['billing_sdi'])) {
            update_post_meta($order_id, '_billing_sdi', strtoupper(sanitize_text_field($_POST['billing_sdi'])));
        }
    }
    
    public function display_admin_order_meta($order) {
        $order_id = $order->get_id();
        $customer_type = get_post_meta($order_id, '_billing_customer_type', true);
        
        echo '<div class="order_data_column" style="clear:both; margin-top:20px;">';
        echo '<h3>' . esc_html__('Dati Fiscali', 'wc-campi-fiscali-italiani') . '</h3>';
        
        if ($customer_type) {
            $type_label = $customer_type === 'private' ? esc_html__('Privato', 'wc-campi-fiscali-italiani') : esc_html__('Azienda', 'wc-campi-fiscali-italiani');
            echo '<p><strong>' . esc_html__('Tipo Cliente:', 'wc-campi-fiscali-italiani') . '</strong> ' . esc_html($type_label) . '</p>';
        }
        
        if ($customer_type === 'private') {
            $cf = get_post_meta($order_id, '_billing_codice_fiscale', true);
            if ($cf) {
                echo '<p><strong>' . esc_html__('Codice Fiscale:', 'wc-campi-fiscali-italiani') . '</strong> ' . esc_html($cf) . '</p>';
            }
        }
        
        if ($customer_type === 'business') {
            $piva = get_post_meta($order_id, '_billing_partita_iva', true);
            $pec = get_post_meta($order_id, '_billing_pec', true);
            $sdi = get_post_meta($order_id, '_billing_sdi', true);
            
            if ($piva) {
                echo '<p><strong>' . esc_html__('Partita IVA:', 'wc-campi-fiscali-italiani') . '</strong> ' . esc_html($piva) . '</p>';
            }
            if ($pec) {
                echo '<p><strong>' . esc_html__('PEC:', 'wc-campi-fiscali-italiani') . '</strong> ' . esc_html($pec) . '</p>';
            }
            if ($sdi) {
                echo '<p><strong>' . esc_html__('Codice SDI:', 'wc-campi-fiscali-italiani') . '</strong> ' . esc_html($sdi) . '</p>';
            }
        }
        
        echo '</div>';
    }
    
    public function display_order_details($order) {
        $order_id = $order->get_id();
        $customer_type = get_post_meta($order_id, '_billing_customer_type', true);
        
        if (!$customer_type) {
            return;
        }
        
        echo '<h2 class="woocommerce-column__title">' . esc_html__('Dati Fiscali', 'wc-campi-fiscali-italiani') . '</h2>';
        echo '<address>';
        
        $type_label = $customer_type === 'private' ? esc_html__('Privato', 'wc-campi-fiscali-italiani') : esc_html__('Azienda', 'wc-campi-fiscali-italiani');
        echo '<p><strong>' . esc_html__('Tipo Cliente:', 'wc-campi-fiscali-italiani') . '</strong> ' . esc_html($type_label) . '</p>';
        
        if ($customer_type === 'private') {
            $cf = get_post_meta($order_id, '_billing_codice_fiscale', true);
            if ($cf) {
                echo '<p><strong>' . esc_html__('Codice Fiscale:', 'wc-campi-fiscali-italiani') . '</strong><br>' . esc_html($cf) . '</p>';
            }
        }
        
        if ($customer_type === 'business') {
            $piva = get_post_meta($order_id, '_billing_partita_iva', true);
            $pec = get_post_meta($order_id, '_billing_pec', true);
            $sdi = get_post_meta($order_id, '_billing_sdi', true);
            
            if ($piva) {
                echo '<p><strong>' . esc_html__('Partita IVA:', 'wc-campi-fiscali-italiani') . '</strong><br>' . esc_html($piva) . '</p>';
            }
            if ($pec) {
                echo '<p><strong>' . esc_html__('PEC:', 'wc-campi-fiscali-italiani') . '</strong><br>' . esc_html($pec) . '</p>';
            }
            if ($sdi) {
                echo '<p><strong>' . esc_html__('Codice SDI:', 'wc-campi-fiscali-italiani') . '</strong><br>' . esc_html($sdi) . '</p>';
            }
        }
        
        echo '</address>';
    }
    
    public function add_custom_email_fields($fields, $sent_to_admin, $order) {
        $order_id = $order->get_id();
        $customer_type = get_post_meta($order_id, '_billing_customer_type', true);
        
        if ($customer_type === 'private') {
            $cf = get_post_meta($order_id, '_billing_codice_fiscale', true);
            if ($cf) {
                $fields['codice_fiscale'] = array(
                    'label' => esc_html__('Codice Fiscale', 'wc-campi-fiscali-italiani'),
                    'value' => $cf
                );
            }
        }
        
        if ($customer_type === 'business') {
            $piva = get_post_meta($order_id, '_billing_partita_iva', true);
            $pec = get_post_meta($order_id, '_billing_pec', true);
            $sdi = get_post_meta($order_id, '_billing_sdi', true);
            
            if ($piva) {
                $fields['partita_iva'] = array(
                    'label' => esc_html__('Partita IVA', 'wc-campi-fiscali-italiani'),
                    'value' => $piva
                );
            }
            if ($pec) {
                $fields['pec'] = array(
                    'label' => esc_html__('PEC', 'wc-campi-fiscali-italiani'),
                    'value' => $pec
                );
            }
            if ($sdi) {
                $fields['sdi'] = array(
                    'label' => esc_html__('Codice SDI', 'wc-campi-fiscali-italiani'),
                    'value' => $sdi
                );
            }
        }
        
        return $fields;
    }
    
    public function enqueue_scripts() {
        if (is_checkout()) {
            wp_enqueue_script(
                'wc-campi-fiscali-italiani',
                plugin_dir_url(__FILE__) . 'assets/js/checkout.js',
                array('jquery'),
                '1.0.0',
                true
            );
        }
    }
}

// Inizializza il plugin
WC_Campi_Fiscali_Italiani::get_instance();